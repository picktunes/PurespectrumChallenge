package comet.book.service;

import comet.book.domain.entity.BookInventory;
import comet.book.domain.repository.Repository;
import comet.book.utils.http.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * Service responsible for handing operations and business rules related to book inventories.
 */
@Service
@Scope("singleton")
public class BookInventoryService {

    /**
     * Repository.
     */
    @Autowired
    private Repository<BookInventory> repository;

    /**
     * Add a quantity to a book inventory.
     *
     * @param bookId Book identifier.
     * @param qty    Quantity to be added.
     * @return Inventory addition result.
     */
    public ResponseEntity<Response> addToInventory(final Long bookId, final Long qty) {
        final BookInventory inventory = getBookInventory(bookId);

        inventory.setBook(bookId);
        inventory.setQuantity(inventory.getQuantity() + qty);
        repository.delete(inventory);
        repository.save(inventory);
        return Response.ok(inventory);
    }

    /**
     * Subtracts a quantity from a book inventory.
     *
     * @param bookId Book identifier.
     * @param qty    Quantity to be subtracted.
     * @return Inventory subtraction result.
     */
    public ResponseEntity<Response> removeFromInventory(final Long bookId, final Long qty) {
        final BookInventory inventory = findInventory(bookId);

        if (inventory == null) {
            return Response.invalid("There is no inventory for this book.");
        }

        if (inventoryQuantityWouldBeNegative(qty, inventory)) {
            return Response.invalid(String.format("The system cannot have a negative inventory. Current inventory: %d", inventory.getQuantity()));
        }

        inventory.setQuantity(inventory.getQuantity() - qty);
        repository.delete(inventory);
        repository.save(inventory);
        return Response.ok(inventory);
    }

    /**
     * Find an inventory for a specific book.
     *
     * @param bookId Book identifier.
     * @return Inventory.
     */
    public BookInventory findInventory(final Long bookId) {
        return repository.get().stream()
                .filter(inventory -> inventory.getBook().equals(bookId))
                .findAny()
                .orElse(null);
    }

    private boolean inventoryQuantityWouldBeNegative(Long qty, BookInventory inventory) {
        return inventory.getQuantity() - qty < 0;
    }

    private BookInventory getBookInventory(Long bookId) {
        /* Try to find an inventory for the specified book.*/
        BookInventory inventory = findInventory(bookId);

        /* If there is no inventory, create a new one.*/
        if (inventory == null) {
            inventory = createNewInventory();
        }
        return inventory;
    }

    private BookInventory createNewInventory() {
        BookInventory inventory;
        inventory = new BookInventory();
        inventory.setId(repository.getNextId());
        inventory.setQuantity(0L);
        return inventory;
    }

    public void resetInventory() {
        repository.reset();
    }

}
