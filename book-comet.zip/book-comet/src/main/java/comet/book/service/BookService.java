package comet.book.service;

import comet.book.domain.entity.Book;
import comet.book.domain.entity.BookInventory;
import comet.book.domain.repository.Repository;
import comet.book.utils.http.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * Service responsible for handing operations and business rules related to books.
 */

@Service
@Scope("singleton")
public class BookService {

    /**
     * Repository.
     */
    @Autowired
    private Repository<Book> repository;

    /**
     * Book inventory repository.
     */
    @Autowired
    private BookInventoryService bookInventoryService;

    /**
     * Find all book on the database.
     *
     * @return List of books.
     */
    public ResponseEntity<Response> findAllBooks() {
        return Response.ok(repository.get());
    }

    /**
     * Create a new book on the database.
     *
     * @param book Book to be created.
     * @return Book creation result.
     */
    public ResponseEntity<Response> createNewBook(final Book book) {
        if (bookExistsOnTheDatabase(book)) {
            return Response.invalid("Book already exists.");
        }

        book.setId(repository.getNextId());

        return Response.ok(repository.save(book));
    }

    /**
     * Updates a book on the database.
     *
     * @param book Book to be updated.
     * @return Book update result.
     */
    public ResponseEntity<Response> updateBook(final Book book) {
        if (!bookExistsOnTheDatabase(book)) {
            return Response.invalid("Book doesn't exists.");
        }

        final Book newBook = (Book) book.clone();
        repository.delete(book);
        return Response.ok(repository.save(newBook));
    }

    /**
     * Deletes a book from the database.
     *
     * @param book Book to be deleted.
     * @return Book deletion result.
     */
    public ResponseEntity<Response> deleteBook(final Book book) {
        final Book bookToBeDeleted = getBookToBeDeleted(book);

        if (bookToBeDeleted == null) {
            return Response.invalid("Book doesn't exists.");
        }

        final BookInventory inventory = bookInventoryService.findInventory(bookToBeDeleted.getId());

        if (bookHasInventoryWithPositiveQuantity(inventory)) {
            return Response.invalid(String.format("The system cannot remove a book with positive inventory. Current inventory: %d", inventory.getQuantity()));
        }

        return Response.ok(repository.delete(bookToBeDeleted));
    }

    /**
     * Checks if a book exists.
     *
     * @param book Book to be verified.
     * @return Boolean value containing if the book exists.
     */
    public boolean bookExistsOnTheDatabase(final Book book) {
        return findBook(book) != null;
    }

    /**
     * Checks if a book exists on the database.
     *
     * @param id Book identifier to be verified.
     * @return Boolean value containing if the book exists.
     */
    public boolean bookExistsOnTheDatabase(final Long id) {
        return findBook(id) != null;
    }

    private boolean bookHasInventoryWithPositiveQuantity(final BookInventory inventory) {
        return inventory != null && inventory.getQuantity() > 0;
    }

    private Book getBookToBeDeleted(Book book) {
        return book.getId() != null ? findBook(book.getId()) : findBook(book);
    }

    private Book findBook(final Long book) {
        return repository.get().stream()
                .filter(bookFilter -> bookFilter.getId().equals(book))
                .findAny()
                .orElse(null);
    }

    private Book findBook(final Book book) {
        return repository.get().stream()
                .filter(bookFilter -> bookFilter.getName().equals(book.getName()))
                .filter(bookFilter -> bookFilter.getAuthors().equals(book.getAuthors()))
                .findAny()
                .orElse(null);
    }

    public void resetBooks() {
        repository.reset();
    }

}
