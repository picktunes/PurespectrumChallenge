package comet.book.endpoint;

import comet.book.domain.entity.BookInventory;
import comet.book.service.BookInventoryService;
import comet.book.service.BookService;
import comet.book.utils.http.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoint responsible for handling requests related to inventory operations.
 */
@RestController
public class BookInventoryEndpoint {

    /**
     * Service related to book operations.
     */
    @Autowired
    private BookService bookService;

    /**
     * Service related to inventory operations.
     */
    @Autowired
    private BookInventoryService service;

    /**
     * Add a quantity to an inventory. If there is no inventory for the specified book, a new one is created.
     *
     * @param inventory Inventory to be added.
     * @return Inventory addition result.
     */
    @PostMapping("/book/inventory/add")
    public ResponseEntity<Response> addToInventory(@RequestBody final BookInventory inventory) {
        if (!bookService.bookExistsOnTheDatabase(inventory.getBook())) {
            return Response.invalid("Book doesn't exists.");
        }

        return service.addToInventory(inventory.getBook(), inventory.getQuantity());
    }

    /**
     * Subtract a quantity from an inventory.
     *
     * @param inventory Inventory to be subtracted.
     * @return Inventory subtraction result.
     */
    @PostMapping("/book/inventory/remove")
    public ResponseEntity<Response> removeFromInventory(@RequestBody final BookInventory inventory) {
        if (!bookService.bookExistsOnTheDatabase(inventory.getBook())) {
            return Response.invalid("Book doesn't exists.");
        }

        return service.removeFromInventory(inventory.getBook(), inventory.getQuantity());
    }

}
