package comet.book.endpoint;

import comet.book.domain.entity.Book;
import comet.book.service.BookService;
import comet.book.utils.http.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Endpoint responsible for handling requests related to book operations.
 */
@RestController
public class BookEndpoint {

    /**
     * Service related to book operations.
     */
    @Autowired
    private BookService service;

    /**
     * Finds every book in the database.
     *
     * @return Every book in the database.
     */
    @GetMapping("/book")
    public ResponseEntity<Response> findAllBooks() {
        return service.findAllBooks();
    }

    /**
     * Create a new book on the database.
     *
     * @param book Book to be created.
     * @return Book creation result.
     */
    @PostMapping("/book")
    public ResponseEntity<Response> addNewBook(@RequestBody final Book book) {
        return service.createNewBook(book);
    }

    /**
     * Update a book already in the database.
     *
     * @param book Book to be updated.
     * @return Book update result.
     */
    @PutMapping("/book")
    public ResponseEntity<Response> updateBook(@RequestBody final Book book) {
        return service.updateBook(book);
    }

    /**
     * Deletes a book already in the database.
     *
     * @param book Book to be deleted.
     * @return Book deletion result.
     */
    @DeleteMapping("/book")
    public ResponseEntity<Response> deleteBook(@RequestBody final Book book) {
        return service.deleteBook(book);
    }

}
