package comet.book.domain.repository;

import comet.book.domain.entity.Book;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Repository implementation for {@link Book}.
 */
@Service
@Scope("singleton")
public class BookRepository implements Repository<Book> {

    private final List<Book> books = new ArrayList<>();

    @Override
    public List<Book> get() {
        return books;
    }

    @Override
    public Book save(Book data) {
        books.add(data);
        return data;
    }

    @Override
    public boolean delete(Book data) {
        final Book foundBook = books.stream()
                .filter(book -> book.getId().equals(data.getId()))
                .findAny()
                .orElse(null);

        return books.remove(foundBook);
    }

    @Override
    public void reset() {
        books.clear();
    }
}
