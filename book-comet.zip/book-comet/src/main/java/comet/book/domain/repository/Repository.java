package comet.book.domain.repository;

import java.util.List;

/**
 * Repository interface. Used for data access.
 *
 * @param <T> Class which this repository works with.
 */
public interface Repository<T> {

    /**
     * Retrieves next sequential identifier.
     *
     * @return Long value containing a sequence.
     */
    default Long getNextId() {
        return (long) (get().size() + 1);
    }

    /**
     * Retrieves every record of the specified class.
     *
     * @return {@link List}.
     */
    List<T> get();

    /**
     * Persists an object.
     *
     * @param data Object to be persisted.
     * @return Persisted object.
     */
    T save(T data);

    /**
     * Deletes an object.
     *
     * @param data Object to be deleted.
     * @return Boolean value containing if the object was successfully deleted.
     */
    boolean delete(T data);

    /**
     * Reset the repository.
     */
    void reset();

}
