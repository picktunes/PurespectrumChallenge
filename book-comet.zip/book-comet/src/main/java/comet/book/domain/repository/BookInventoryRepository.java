package comet.book.domain.repository;

import comet.book.domain.entity.BookInventory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


/**
 * Repository implementation for {@link BookInventory}.
 */
@Service
@Scope("singleton")
public class BookInventoryRepository implements Repository<BookInventory> {

    private final List<BookInventory> inventories = new ArrayList<>();

    @Override
    public List<BookInventory> get() {
        return inventories;
    }

    @Override
    public BookInventory save(BookInventory data) {
        inventories.add(data);
        return data;
    }

    @Override
    public boolean delete(BookInventory data) {
        final BookInventory foundInventory = inventories.stream()
                .filter(inventory -> inventory.getId().equals(data.getId()))
                .findAny()
                .orElse(null);
        return inventories.remove(foundInventory);
    }

    @Override
    public void reset() {
        inventories.clear();
    }
}
