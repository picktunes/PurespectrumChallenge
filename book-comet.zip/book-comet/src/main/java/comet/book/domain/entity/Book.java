package comet.book.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 * Entity representing a book.
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.DEDUCTION, defaultImpl = Book.class)
@JsonSubTypes({@JsonSubTypes.Type(ElectronicBook.class)})
public class Book implements Cloneable {

    private Long id;
    private String name;
    private String authors;
    private String publishers;
    private Long publicationYear;
    private String summary;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getPublishers() {
        return publishers;
    }

    public void setPublishers(String publishers) {
        this.publishers = publishers;
    }

    public Long getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(Long publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    @Override
    public Object clone() {
        Book book = null;
        try {
            book = (Book) super.clone();
            book.setId(getId());
            book.setAuthors(getAuthors());
            book.setName(getName());
            book.setPublishers(getPublishers());
            book.setPublicationYear(getPublicationYear());
            book.setSummary(getSummary());
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return book;
    }
}
