package comet.book.domain.entity;

/**
 * Entity representing an electronic book.
 * An electronic book contains every information of a book and also contains the file format (PDF, EPUB, etc).
 */
public class ElectronicBook extends Book implements Cloneable {

    private String format;

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }


    @Override
    public Object clone() {
        final ElectronicBook book = (ElectronicBook) super.clone();
        book.setFormat(getFormat());
        return book;
    }
}
