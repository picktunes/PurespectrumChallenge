package comet.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookCometApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookCometApiApplication.class, args);
    }

}
