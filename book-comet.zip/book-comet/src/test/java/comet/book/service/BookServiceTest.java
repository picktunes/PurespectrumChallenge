package comet.book.service;

import comet.book.domain.entity.Book;
import comet.book.utils.http.Response;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class BookServiceTest {

    @Autowired
    private BookService service;

    @AfterEach
    void resetRepository() {
        service.resetBooks();
    }

    @Test
    @Order(1)
    void givenAnEmptyList_whenFindingAllBooks_shouldBeEmpty() {
        final Response response = service.findAllBooks().getBody();
        final List<Book> books = (List<Book>) response.getData();
        Assertions.assertNotNull(books);
        Assertions.assertTrue(books.isEmpty());
    }

    @Test
    @Order(2)
    void givenCreatingANewBook_whenCreatingABookThatNotExists_HttpStatusShouldBeOk() {
        final Book book = getMockBook();
        final ResponseEntity<Response> response = service.createNewBook(book);
        Assertions.assertNotNull(response);
        Assertions.assertSame(response.getStatusCode(), HttpStatus.OK);
    }

    @Test
    @Order(3)
    void givenCreatingANewBook_whenCreatingABookThatExists_HttpStatusShouldNotBeOk() {
        final Book book = getMockBook();
        final ResponseEntity<Response> response = service.createNewBook(book);
        Assertions.assertNotNull(response);
        Assertions.assertSame(response.getStatusCode(), HttpStatus.OK);
        final ResponseEntity<Response> anotherResponse = service.createNewBook(book);
        Assertions.assertNotNull(anotherResponse);
        Assertions.assertNotSame(anotherResponse.getStatusCode(), HttpStatus.OK);
    }

    private Book getMockBook() {
        final Book book = new Book();
        book.setName("A book");
        book.setPublicationYear(2020L);
        book.setAuthors("John Doe");
        book.setPublishers("GoodBooks Inc");
        book.setSummary("Lorem Ipsum");
        return book;
    }

}