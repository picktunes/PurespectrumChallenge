package comet.book.service;

import comet.book.domain.entity.Book;
import comet.book.domain.entity.BookInventory;
import comet.book.utils.http.Response;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.annotation.PostConstruct;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class BookInventoryServiceTest {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookInventoryService bookInventoryService;

    @AfterEach
    void resetRepository() {
        bookService.resetBooks();
        bookInventoryService.resetInventory();
    }

    @Test
    @Order(1)
    void givenAnExistingBook_whenAddingQuantityToItsInventory_shouldBeOk() {
        bookService.createNewBook(getMockBook());
        final BookInventory inventory = new BookInventory();
        inventory.setBook(1L);
        inventory.setQuantity(10L);
        final ResponseEntity<Response> response = bookInventoryService.addToInventory(inventory.getBook(), inventory.getQuantity());
        Assertions.assertNotNull(response);
        Assertions.assertSame(response.getStatusCode(), HttpStatus.OK);
    }

    @Test
    @Order(2)
    void givenAnExistingBook_whenSubtractingMoreQuantityToItsInventoryThanItCurrentlyHas_shouldNotBeOk() {
        bookService.createNewBook(getMockBook());
        bookInventoryService.addToInventory(1L, 10L);
        final BookInventory inventory = new BookInventory();
        inventory.setBook(1L);
        inventory.setQuantity(20L);
        final ResponseEntity<Response> response = bookInventoryService.removeFromInventory(inventory.getBook(), inventory.getQuantity());
        Assertions.assertNotNull(response);
        Assertions.assertNotSame(response.getStatusCode(), HttpStatus.OK);
    }

    private Book getMockBook() {
        final Book book = new Book();
        book.setName("A book");
        book.setPublicationYear(2020L);
        book.setAuthors("John Doe");
        book.setPublishers("GoodBooks Inc");
        book.setSummary("Lorem Ipsum");
        return book;
    }
}